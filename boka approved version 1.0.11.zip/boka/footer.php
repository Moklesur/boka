<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package boka
 */

?>

<footer class="footer-main">
	<?php if ( (is_active_sidebar( 'boka-footer-widget-1' ) ) || ( is_active_sidebar( 'boka-footer-widget-2' ))  || ( is_active_sidebar( 'boka-footer-widget-3' ) )) : ?>
	<!--------------- Footer Top ---------------->
	<section class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-6 col-xs-12">
					<?php
					if ( is_active_sidebar( 'boka-footer-widget-1' ) ) :
						dynamic_sidebar( 'boka-footer-widget-1' );
					endif;
					?>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12">
					<?php
					if ( is_active_sidebar( 'boka-footer-widget-2' ) ) :
						dynamic_sidebar( 'boka-footer-widget-2' );
					endif;
					?>
				</div>
				<div class="col-md-5 col-sm-12 col-xs-12">
					<?php
					if ( is_active_sidebar( 'boka-footer-widget-3' ) ) :
						dynamic_sidebar( 'boka-footer-widget-3' );
					endif;
					?>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!--------------- Footer bottom ---------------->
	<section class="footer-bottom">
		<div class="container">
			<div class="row">
				<?php do_action('boka_bottom_footer_copyright'); ?>
			</div>
		</div>
	</section>
</footer>
</div>
<?php wp_footer(); ?>

</body>
</html>
