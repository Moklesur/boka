<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package boka
 */

$margin[] = 'padding-gap-6 overflow blog-link';
$sticky_post = '';
if ( is_sticky() ){
	$sticky_post = ' sticky-post';
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class($margin); ?>>
	<header class="entry-header margin-bottom-20">
		<?php
		if ( is_single() ) {
			the_title( '<h3 class="entry-title text-capitalize margin-null">', '</h3>' );
		} else {
			the_title( '<h3 class="entry-title margin-null text-capitalize'. $sticky_post .'"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
		}

		if ( 'post' === get_post_type() ) : ?>
			<div class="entry-meta margin-top-10">
				<?php boka_posted_on(); ?>
			</div><!-- .entry-meta -->
			<?php
		endif; ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php if ( has_post_thumbnail() ) : ?>
			<div class="entry-thumb">
				<a href="<?php the_permalink(); ?>">
					<img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-responsive margin-top-20 margin-bottom-20" />
				</a>
			</div>
		<?php endif;

		if(is_single()) :
			the_content();
		else:
			$excerpt = get_theme_mod('excerpt_lenght', '55');
			//return $excerpt;
			the_excerpt();
		endif;

		wp_link_pages( array(
			'before' => '<div class="page-links">' . __( 'Pages:', 'boka' ),
			'after'  => '</div>',
		) );
		?>
		<div class="clearfix"></div>
	</div><!-- .entry-content -->

	<footer class="entry-footer overflow">
		<?php if(!is_single()) : ?>
		<div class="pull-left">
			<a href="<?php echo esc_url( get_permalink() ); ?>" class="btn btn-default margin-top-10"><?php _e( 'Continue Reading', 'boka' )?></a>
		</div>
		<?php endif; ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
